package com.ibrahim.salesforce.response

import com.google.gson.annotations.SerializedName

data class GetClassResponse( @SerializedName("Classes") val Classs: List<Clas>)



