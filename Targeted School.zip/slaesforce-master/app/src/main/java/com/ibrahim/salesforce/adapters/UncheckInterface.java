package com.ibrahim.salesforce.adapters;

public interface UncheckInterface {
    void showMsg();
}
