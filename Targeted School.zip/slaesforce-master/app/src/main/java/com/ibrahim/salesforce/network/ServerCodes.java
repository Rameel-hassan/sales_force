package com.ibrahim.salesforce.network;

public class ServerCodes {
    public static final class ServerResultType {
        public static final int SERVER_RESULT_SUCCESS = 1;
        public static final int SERVER_RESULT_FAILURE = 2;
    }
}
