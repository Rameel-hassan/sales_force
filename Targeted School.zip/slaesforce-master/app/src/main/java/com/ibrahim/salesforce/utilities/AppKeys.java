package com.ibrahim.salesforce.utilities;

public interface AppKeys {
    String KEY_LOGIN_RESPONSE = "key_login_response";
    String KEY_KEEP_LOGIN = "key_keep_login";
    String FRAGMENT_TYPE = "fragment_type";
    String KEY_BASE_URL = "key_base_url";
    String KEY_ARGUMENT_DATA = "key_argument_data";
    String DIALOG_DEV_CONFIRMATION = "dev_confirmation_dialog_fragment";

}
