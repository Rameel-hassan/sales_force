package com.ibrahim.salesforce.activity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.ibrahim.salesforce.R;
import com.ibrahim.salesforce.adapters.AddRemoveItem;
import com.ibrahim.salesforce.adapters.BookSellerItemsAdapter;
import com.ibrahim.salesforce.adapters.SelectedBookSellerItemsAdapter;
import com.ibrahim.salesforce.adapters.SelectedPublisherItemsAdapter;
import com.ibrahim.salesforce.model.SampleSearchModel;
import com.ibrahim.salesforce.network.ApiService;
import com.ibrahim.salesforce.network.RequestCode;
import com.ibrahim.salesforce.network.RestCallbackObject;
import com.ibrahim.salesforce.network.RestClient;
import com.ibrahim.salesforce.network.ServerCodes;
import com.ibrahim.salesforce.network.ServerConnectListenerObject;
import com.ibrahim.salesforce.request.SchoolRegRequest;
import com.ibrahim.salesforce.response.BookPublisherID;
import com.ibrahim.salesforce.response.BookSellerID;
import com.ibrahim.salesforce.response.CurrentSyllabus;
import com.ibrahim.salesforce.response.CustomersRelatedtoSO;
import com.ibrahim.salesforce.response.Fee;
import com.ibrahim.salesforce.response.FormData;
import com.ibrahim.salesforce.response.GetAreasResponse;
import com.ibrahim.salesforce.response.GetBookSellerResponse;
import com.ibrahim.salesforce.response.GetCitiesResponse;
import com.ibrahim.salesforce.response.GetServerResponse;
import com.ibrahim.salesforce.response.IdName;
import com.ibrahim.salesforce.response.Region;
import com.ibrahim.salesforce.response.ServerResponse;
import com.ibrahim.salesforce.utilities.AppKeys;
import com.ibrahim.salesforce.utilities.Utility;

import java.util.ArrayList;
import java.util.List;

import io.paperdb.Paper;
import ir.mirrajabi.searchdialog.SimpleSearchDialogCompat;
import ir.mirrajabi.searchdialog.core.BaseSearchDialogCompat;
import ir.mirrajabi.searchdialog.core.SearchResultListener;
import retrofit2.Call;

public class EditSchoolInformation extends AppCompatActivity implements ServerConnectListenerObject, View.OnClickListener, AddRemoveItem.AddRemoveBookSellers, AddRemoveItem.AddRemoveSyllabus {
    Spinner SnpName, mSpnRegion, mSpnCity, mSpnArea, mSpnNewCity, mSpnNewArea, mSpnNewDistrict, mSpnNewTehsil, mSpnEduSys, mSpnFeeStruct, mSpnSyllSelectionDate, mSpnSessionDate;
    RecyclerView mrvItems;
    ImageButton ibShowPublishers;
    private GetServerResponse mLoginResponse;
    private GetCitiesResponse mCitiesResponse;
    private GetAreasResponse mAreaResponse;
    private GetAreasResponse mNewAreaResponse;
    private GetBookSellerResponse mBookSellersResponse;
    private ApiService mService;
    int soId;
    private String cityId;
    String Token;
    int studentStrength = 0;
    int cityIDtOSend = 0, areaIDtoSend = 0;
    RecyclerView mRvSellers;
    RecyclerView.LayoutManager sellerLayoutManager, mLayoutManager;
    RecyclerView.Adapter sellerAdapter, mAdapter;
    RelativeLayout rlShowSellers;
    private ArrayAdapter<CustomersRelatedtoSO> customerAdapter;
    private RelativeLayout rlShowPublishers;
    List<CustomersRelatedtoSO> mArrCustomers;
    List<GetCitiesResponse.City> arrCitiesRelatedToRegion;
    List<GetCitiesResponse.City> arrNewCities;
    ArrayList<SampleSearchModel> sampleSearchModels;
    ArrayList<SampleSearchModel> newSampleSearchModels;
    ArrayList<SampleSearchModel> schoolSampleSearchModels;
    List<FormData> editSchoolInformations;
    private List<GetAreasResponse.Area> mArrAreas;
    private List<GetAreasResponse.Area> mArrNewAreas;
    private List<GetBookSellerResponse.BookSeller> mArrBookSellers;
    private List<GetBookSellerResponse.BookSeller> mArrSelectedBookSellers;
    private List<String> mArrEduSys;
    private List<Fee> mArrFeeStructure;
    private List<String> mArrSessionDate;
    private List<String> mArrBookShop;
    private List<String> mArrSyllSelectionDate;
    private List<CurrentSyllabus> mArrSyllabusItems;
    private List<CurrentSyllabus> mArrSyllabusItemsSelected;
    EditSchoolInformation editSchoolInformation;
    private ProgressDialog mDialog;
    List<Region> mArrRegion;
    LinearLayout llMainLayout;
    String oldDistrict = "";
    int oldDistrID = 0;
    String oldTehsil = "";
    int oldTehsID = 0;
    FormData formData;
    SchoolRegRequest schoolRegRequest;
    private int regionPosition, customerPosition = 0, cityPosition = 0, areaPosition = 0, newCityPosition = 0, newAreaPosition = 0, districtPosition = 0, tehsilPosition = 0;
    private ArrayAdapter<GetCitiesResponse.City> cityAdapter;
    private ArrayAdapter<GetCitiesResponse.City> newCityAdapter;
    EditText edtShopname, etdOwerName, edtcellno, edtcellnotwo, edtemail, edtaddress, edtcontactperson, edtcontactcellno, edtstudentstr, edtNoOfTeacher, edtNoOfBraches;
    Button btnsbm;
    private List<IdName> mArrDistricts;
    private List<IdName> mArrTehsils;
    private ImageButton ibshowSellers;
    private ScrollView scrlEdit;
    private ArrayAdapter<String> adapter;
    private int districtID = 0, tehsilID = 0;
    private List<BookSellerID> BookSellerIDs;
    private List<BookPublisherID> PublisherIDs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Paper.init(EditSchoolInformation.this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.school_edit_information_activity);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Edit School Information");
        mArrCustomers = new ArrayList<>();
        mArrAreas = new ArrayList<>();
        mArrNewAreas = new ArrayList<>();
        arrCitiesRelatedToRegion = new ArrayList<>();
        sampleSearchModels = new ArrayList<>();
        newSampleSearchModels = new ArrayList<>();
        editSchoolInformations = new ArrayList<>();
        schoolSampleSearchModels = new ArrayList<>();
        mArrBookSellers = new ArrayList<>();
        mArrSelectedBookSellers = new ArrayList<>();
        mArrSyllabusItems = new ArrayList<>();
        mArrSyllabusItemsSelected = new ArrayList<>();
        mArrDistricts = new ArrayList<>();
        mArrTehsils = new ArrayList<>();
        init();
        Log.d("class_name", this.getClass().getSimpleName());
    }

    private void init() {
        SnpName = findViewById(R.id.spnShopName);
        mSpnRegion = findViewById(R.id.spn_edit_region);
        mSpnCity = findViewById(R.id.spn_edit_city);
        mSpnArea = findViewById(R.id.spn_edit_area);
        mSpnNewCity = findViewById(R.id.spn_new_City);
        mSpnNewArea = findViewById(R.id.spn_new_area);
        mSpnNewDistrict = findViewById(R.id.spn_new_District);
        mSpnNewTehsil = findViewById(R.id.spn_new_Tehsil);
        mSpnEduSys = findViewById(R.id.spn_edit_edu_sys);
        mSpnFeeStruct = findViewById(R.id.spn_edit_fee_struct);
        mSpnSyllSelectionDate = findViewById(R.id.spn_edit_syll_sel_month);
        mSpnSessionDate = findViewById(R.id.spn_edit_sess_start_month);
        rlShowPublishers = findViewById(R.id.rl_select_Publishers);
        mrvItems = findViewById(R.id.rv_publishers);
        ibShowPublishers = findViewById(R.id.ib_show_publisher);
        edtShopname = findViewById(R.id.etShopName);
        etdOwerName = findViewById(R.id.etOwerName);
        edtcellno = findViewById(R.id.etCellNo1);
        edtcellnotwo = findViewById(R.id.etCellNo2);
        edtemail = findViewById(R.id.etEmail);
        mDialog = new ProgressDialog(EditSchoolInformation.this);
        mDialog.setCancelable(false);
        edtaddress = findViewById(R.id.etAddress);
        edtcontactperson = findViewById(R.id.etContactPerson);
        edtcontactcellno = findViewById(R.id.etContactPersonCellNo);
        edtstudentstr = findViewById(R.id.etStudentStrength);
        edtNoOfBraches = findViewById(R.id.etNoOfBranches);
        mRvSellers = findViewById(R.id.rv_sellers);
        edtNoOfTeacher = findViewById(R.id.etNoOfTeachers);
        mLoginResponse = Paper.book().read(AppKeys.KEY_LOGIN_RESPONSE);
        btnsbm = findViewById(R.id.btnSubmit);
        ibshowSellers = findViewById(R.id.ib_show_seller);
        rlShowSellers = findViewById(R.id.rl_select_Sellers);
        llMainLayout = findViewById(R.id.llMain);
        scrlEdit = findViewById(R.id.scrlEdit);
        btnsbm.setOnClickListener(this);
        rlShowPublishers.setOnClickListener(this);
        ibShowPublishers.setOnClickListener(this);
        ibshowSellers.setOnClickListener(this);
        rlShowSellers.setOnClickListener(this);
        soId = mLoginResponse.getData().getSOID();
        Token = mLoginResponse.getData().getToken();
        mArrSyllabusItems = mLoginResponse.getData().getCurrentSyllabus();
        setRegionSpinner();
        //callGetDistrictService();
    }

    private void setRegionSpinner() {
        mArrRegion = mLoginResponse.getData().getRegion();
//        if (mArrRegion.size() > 1) {
//            Region region = new Region(0, "Select Region");
//            mArrRegion.add(0, region);
//        } else
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                callCityService();
            }
        }, 600);
        ArrayAdapter<Region> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, mArrRegion);
        mSpnRegion.setAdapter(adapter);
        mSpnRegion.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (Utility.isNetworkAvailable(getApplicationContext())) {
                    regionPosition = position;
                    callCityService();
                } else
                    Toast.makeText(getApplicationContext(), getString(R.string.str_no_internet), Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });

    }

    private void setCitySpinner() {
        cityAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, arrCitiesRelatedToRegion);
        mSpnCity.setAdapter(cityAdapter);
        sampleSearchModels.clear();
        for (int i = 0; i < arrCitiesRelatedToRegion.size(); i++) {
            GetCitiesResponse.City city = arrCitiesRelatedToRegion.get(i);
            String name = city.getName();
            int id = city.getID();
            sampleSearchModels.add(new SampleSearchModel(name, id));

        }
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    callGetAreaService(String.valueOf(arrCitiesRelatedToRegion.get(cityPosition).getID()));
                } catch (Exception ex) {
                    Toast.makeText(getApplicationContext(), "Please Wait for data to populate", Toast.LENGTH_LONG).show();
                }
            }
        }, 600);
        mDialog.dismiss();
        mSpnCity.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    arrCitiesRelatedToRegion.clear();
                    new SimpleSearchDialogCompat(EditSchoolInformation.this, "Search...",
                            "What are you looking for...?", null, sampleSearchModels,
                            new SearchResultListener<SampleSearchModel>() {
                                @Override
                                public void onSelected(BaseSearchDialogCompat dialog,
                                                       SampleSearchModel item, int position) {
                                    arrCitiesRelatedToRegion.add(new GetCitiesResponse().new City(item.getID(), item.getTitle()));
                                    cityAdapter = new ArrayAdapter<GetCitiesResponse.City>(EditSchoolInformation.this, android.R.layout.simple_spinner_dropdown_item, arrCitiesRelatedToRegion);
                                    mSpnCity.setAdapter(cityAdapter);
                                    mSpnCity.setVisibility(View.VISIBLE);
                                    mSpnCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                        @Override
                                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                            cityPosition = position;
                                            callGetAreaService(String.valueOf(arrCitiesRelatedToRegion.get(cityPosition).getID()));
                                        }

                                        @Override
                                        public void onNothingSelected(AdapterView<?> parent) {
                                        }
                                    });
                                    dialog.dismiss();
                                }
                            }).show();
                }
                return true;
            }
        });
    }

    private void setNewCitySpinner() {
        newCityAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, arrNewCities);
        mSpnNewCity.setAdapter(newCityAdapter);
        newSampleSearchModels.clear();
        for (int i = 0; i < arrNewCities.size(); i++) {
            GetCitiesResponse.City city = arrNewCities.get(i);
            String name = city.getName();
            int id = city.getID();
            newSampleSearchModels.add(new SampleSearchModel(name, id));

        }
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    callGetNewAreaService(String.valueOf(arrNewCities.get(newCityPosition).getID()));
                } catch (Exception ex) {
                    Toast.makeText(getApplicationContext(), "Please Wait for data to populate", Toast.LENGTH_LONG).show();
                }
            }
        }, 600);
        mDialog.dismiss();
        mSpnNewCity.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    arrNewCities.clear();
                    new SimpleSearchDialogCompat(EditSchoolInformation.this, "Search...",
                            "What are you looking for...?", null, newSampleSearchModels,
                            new SearchResultListener<SampleSearchModel>() {
                                @Override
                                public void onSelected(BaseSearchDialogCompat dialog,
                                                       SampleSearchModel item, int position) {
                                    arrNewCities.add(new GetCitiesResponse().new City(item.getID(), item.getTitle()));
                                    newCityAdapter = new ArrayAdapter<GetCitiesResponse.City>(EditSchoolInformation.this, android.R.layout.simple_spinner_dropdown_item, arrNewCities);
                                    mSpnNewCity.setAdapter(newCityAdapter);
                                    mSpnNewCity.setVisibility(View.VISIBLE);
                                    mSpnNewCity.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                        @Override
                                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                            newCityPosition = position;
                                            callGetNewAreaService(String.valueOf(arrNewCities.get(newCityPosition).getID()));
                                        }

                                        @Override
                                        public void onNothingSelected(AdapterView<?> parent) {
                                        }
                                    });
                                    dialog.dismiss();
                                }
                            }).show();
                }
                return true;
            }
        });
    }

    private void setAreaSpinner(GetAreasResponse mAreaResponse) {
        mArrAreas = mAreaResponse.getAreas();
//        GetAreasResponse.Area emptyArea = new GetAreasResponse().new Area(0, "Select Area");
//        mArrAreas.add(0, emptyArea);
        ArrayAdapter<GetAreasResponse.Area> adapter = new ArrayAdapter<>(EditSchoolInformation.this, android.R.layout.simple_spinner_dropdown_item, mArrAreas);
        mSpnArea.setAdapter(adapter);
        mSpnArea.setVisibility(View.VISIBLE);
        mSpnArea.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                //if (position ! 0) {
                    areaPosition = position;
                    GetCustomerRelatedToArea(mArrAreas.get(areaPosition).getID(), arrCitiesRelatedToRegion.get(cityPosition).getID());
                    callGetBookSellerService(String.valueOf(arrCitiesRelatedToRegion.get(cityPosition).getID()), String.valueOf(mArrAreas.get(areaPosition).getID()));
                //}
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void setNewAreaSpinner(GetAreasResponse mAreaResponse) {
        mArrNewAreas = mAreaResponse.getAreas();
        /*GetAreasResponse.Area emptyCity = new GetAreasResponse().new Area(0, "Select Area");
        mArrNewAreas.add(0, emptyCity);*/
        ArrayAdapter<GetAreasResponse.Area> adapter = new ArrayAdapter<>(EditSchoolInformation.this, android.R.layout.simple_spinner_dropdown_item, mArrNewAreas);
        mSpnNewArea.setAdapter(adapter);
        mSpnNewArea.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
               // if (position != 0) {
                    newAreaPosition = position;
                    areaIDtoSend = mArrNewAreas.get(position).getID();
                //}
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void setNewDistrictSpinner() {
        IdName emptyDis = new IdName(0, "Select District");
        mArrDistricts.add(0, emptyDis);
        ArrayAdapter<IdName> adapter = new ArrayAdapter<>(EditSchoolInformation.this, android.R.layout.simple_spinner_dropdown_item, mArrDistricts);
        mSpnNewDistrict.setAdapter(adapter);
        mSpnNewDistrict.setVisibility(View.VISIBLE);
        mSpnNewDistrict.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    districtPosition = position;
                    districtID = mArrDistricts.get(position).getID();
                    callGetTehsilService(mArrDistricts.get(position).getID());

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void setNewTehsilSpinner() {
        mSpnNewTehsil.setVisibility(View.VISIBLE);
        IdName emptyTehsil = new IdName(0, "Select Tehsil");
        mArrTehsils.add(0, emptyTehsil);
        ArrayAdapter<IdName> adapter = new ArrayAdapter<>(EditSchoolInformation.this, android.R.layout.simple_spinner_dropdown_item, mArrTehsils);
        mSpnNewTehsil.setAdapter(adapter);
        mSpnNewTehsil.setVisibility(View.VISIBLE);
        mSpnNewTehsil.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (position != 0) {
                    tehsilPosition = position;
                    tehsilID = mArrTehsils.get(position).getID();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
            }
        });
    }

    private void setCustomerSpinner() {
        SnpName.setVisibility(View.VISIBLE);
        customerAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, mArrCustomers);
        SnpName.setAdapter(customerAdapter);
        schoolSampleSearchModels.clear();
        for (int i = 0; i < mArrCustomers.size(); i++) {
            CustomersRelatedtoSO customer = mArrCustomers.get(i);
            String name = customer.getShopName();
            int id = customer.getID();
            schoolSampleSearchModels.add(new SampleSearchModel(name, id));
        }


        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                try {
                    callService_(mArrCustomers.get(customerPosition).getID());
                } catch (Exception ex) {
                    Toast.makeText(getApplicationContext(), "Please Wait for school to populate", Toast.LENGTH_LONG).show();
                }

            }
        }, 300);
        mDialog.dismiss();
        SnpName.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (event.getAction() == MotionEvent.ACTION_UP) {
                    mArrCustomers.clear();
                    new SimpleSearchDialogCompat(EditSchoolInformation.this, "Search...",
                            "What are you looking for...?", null, schoolSampleSearchModels,
                            new SearchResultListener<SampleSearchModel>() {
                                @Override
                                public void onSelected(BaseSearchDialogCompat dialog,
                                                       SampleSearchModel item, int position) {
                                    mArrCustomers.add(new CustomersRelatedtoSO(item.getID(), false, item.getTitle()));
                                    customerAdapter = new ArrayAdapter<CustomersRelatedtoSO>(EditSchoolInformation.this, android.R.layout.simple_spinner_dropdown_item, mArrCustomers);
                                    SnpName.setAdapter(customerAdapter);
                                    SnpName.setVisibility(View.VISIBLE);
                                    SnpName.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                        @Override
                                        public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                            customerPosition = position;
                                            callService_(mArrCustomers.get(customerPosition).getID());
                                        }

                                        @Override
                                        public void onNothingSelected(AdapterView<?> parent) {
                                        }
                                    });
                                    dialog.dismiss();
                                }
                            }).show();
                }
                return true;
            }
        });


    }


    private void callCityService() {
        mDialog.show();
        mDialog.setMessage("Loading Cities,please wait...");
        mService = RestClient.getInstance(EditSchoolInformation.this);
        Call<GetCitiesResponse> userObject = mService.getCities(mArrRegion.get(regionPosition).getID(), mLoginResponse.getData().getSOID());
        RestCallbackObject callbackObject = new RestCallbackObject(EditSchoolInformation.this, this, RequestCode.GET_CITIES_REQUEST_CODE).showProgress(true, 0).dontHideProgress(false);
        userObject.enqueue(callbackObject);
    }

    private void callGetAreaService(String cityId) {
        mDialog.show();
        mDialog.setMessage("Fetching areas please wait...");
        mService = RestClient.getInstance(getApplicationContext());
        Call<GetAreasResponse> userObject = mService.getAreas(cityId, mLoginResponse.getData().getSOID());
        RestCallbackObject callbackObject = new RestCallbackObject(EditSchoolInformation.this, this, RequestCode.GET_AREA_REQUEST_CODE).showProgress(true, 0).dontHideProgress(false);
        userObject.enqueue(callbackObject);
    }

    private void callGetNewAreaService(String cityId) {
        mDialog.show();
        mDialog.setMessage("Fetching areas please wait...");
        mService = RestClient.getInstance(getApplicationContext());
        Call<GetAreasResponse> userObject = mService.getAreas(cityId, mLoginResponse.getData().getSOID());
        RestCallbackObject callbackObject = new RestCallbackObject(EditSchoolInformation.this, this, RequestCode.GET_AREAS_FOR_CITY).showProgress(true, 0).dontHideProgress(false);
        userObject.enqueue(callbackObject);
    }

    private void callGetBookSellerService(String cityId, String areaId) {
        this.cityId = cityId;
        mDialog.show();
        mDialog.setMessage("Fetching Selllers please wait...");
        mService = RestClient.getInstance(getApplicationContext());
        Call<GetBookSellerResponse> userObject = mService.getSellers(cityId, areaId);
        RestCallbackObject callbackObject = new RestCallbackObject(EditSchoolInformation.this, this, RequestCode.GET_AREA_SELLERS).showProgress(true, 0).dontHideProgress(false);
        userObject.enqueue(callbackObject);

    }

    private void callGetDistrictService() {
        mDialog.setMessage("Fetching Districts please wait...");
        mDialog.show();
        mService = RestClient.getInstance(this);
        Call<GetServerResponse> userObject = mService.getDistricts(mLoginResponse.getData().getProvinceID());
        RestCallbackObject callbackObject = new RestCallbackObject(this, this, RequestCode.GET_DISTRCIST).showProgress(true, 0).dontHideProgress(false);
        userObject.enqueue(callbackObject);
    }

    private void callGetTehsilService(int DitrictID) {
        mDialog.setMessage("Fetching Tehsils please wait...");
        mDialog.show();
        mService = RestClient.getInstance(this);
        mDialog.show();
        Call<GetServerResponse> userObject = mService.getTehsils(DitrictID);
        RestCallbackObject callbackObject = new RestCallbackObject(this, this, RequestCode.GET_TEHSILS).showProgress(true, 0).dontHideProgress(false);
        userObject.enqueue(callbackObject);
    }

    private void GetCustomerRelatedToArea(int areaID, int cityID) {
        mDialog.show();
        mDialog.setMessage("Fetching customers please wait...");
        mService = RestClient.getInstance(this);
        Call<GetServerResponse> userObject = mService.getCustomerRelatedToSo(cityID, areaID);
        RestCallbackObject callbackObject = new RestCallbackObject(this, this, RequestCode.GET_CUSTOMER_RELATED_TO_SO).showProgress(true, 0).dontHideProgress(false);
        userObject.enqueue(callbackObject);
    }

    private void callgetDeeletSchool(int retailerID) {
        mDialog.show();
        mDialog.setMessage("Deleting School,please wait...");
        Call<ServerResponse> userObject = mService.deleteRetailer(retailerID);
        RestCallbackObject callbackObject = new RestCallbackObject(this, this, RequestCode.DELETE_SCHOOLS).showProgress(true, 0).dontHideProgress(false);
        userObject.enqueue(callbackObject);
    }

    public void getEditSchoolInfo(FormData req) {
        mSpnEduSys.setAdapter(null);
        mSpnSessionDate.setAdapter(null);
        mSpnFeeStruct.setAdapter(null);
        mSpnSyllSelectionDate.setAdapter(null);
        edtShopname.setText(req.getShopName());
        etdOwerName.setText(req.getName());
        edtcellno.setText(req.getPhone1());
        edtcellnotwo.setText(req.getPhone2());
        edtemail.setText(req.getEmail());
        edtaddress.setText(req.getAddress());
        edtcontactperson.setText(req.getContactPerson());
        edtcontactcellno.setText(req.getContactPersonCellNo());
        edtstudentstr.setText(String.valueOf(req.getStudentStrength()));
        edtNoOfBraches.setText(String.valueOf(req.getNoOfBranches()));
        edtNoOfTeacher.setText(String.valueOf(req.getNoOfTeachers()));
        setFeeStructureSpinner(req.getFeeStructID());
        setEducationSystemSpinner(req.getEduSystem());
        setSessionStartMonth(req.getSessionStartMonth());
        setSyllabusSelectionMonth(req.getSyllSectionMonth());
        mRvSellers.setVisibility(View.GONE);
        mRvSellers.setAdapter(null);
        mrvItems.setVisibility(View.GONE);
        mrvItems.setAdapter(null);
        ibshowSellers.setBackgroundResource(R.drawable.ic_expand_more_black_24dp);
        ibShowPublishers.setBackgroundResource(R.drawable.ic_expand_more_black_24dp);
        /*mSpnNewCity.setSelection(cityPosition);

         mSpnNewArea.setSelection(areaPosition);*/

        /*for(int j=0;j<=mArrNewAreas.size();j++) {
            if(mArrNewAreas.get(j).getID()==req.getAreaID())
            {            mSpnNewArea.setSelection(j);
                break;
            }

        }*/
        //add the relavent city at top
       /* GetCitiesResponse.City city=new GetCitiesResponse().new City(req.getCityID(),req.getCityName());
        arrNewCities.add(0,city);
        newCityAdapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, arrNewCities);
        mSpnNewCity.setAdapter(newCityAdapter);
        //ADD THE RELAVENT AREA AT TOP
        mArrNewAreas = mAreaResponse.getAreas();
        GetAreasResponse.Area emptyCity = new GetAreasResponse().new Area(req.getAreaID(), req.getAreaName());
        mArrNewAreas.add(0, emptyCity);
        ArrayAdapter<GetAreasResponse.Area> adapter = new ArrayAdapter<>(EditSchoolInformation.this, android.R.layout.simple_spinner_dropdown_item, mArrNewAreas);
        mSpnNewArea.setAdapter(adapter);*/
    }

    private void setEducationSystemSpinner(String Current) {
        mArrEduSys = new ArrayList<>();
        mArrEduSys.add("Select Education System");
        mArrEduSys.add("Primary");
        mArrEduSys.add("Middle");
        mArrEduSys.add("Matric");
        adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, mArrEduSys);
        mSpnEduSys.setAdapter(adapter);
        if (Current != null) {
            int spinnerPosition = adapter.getPosition(Current);
            mSpnEduSys.setSelection(spinnerPosition);
        }
    }

    private void setFeeStructureSpinner(int Current) {
        mArrFeeStructure = mLoginResponse.getData().getFee();
        mArrFeeStructure.add(0, new Fee(0, "Select Fee Structure*"));
        // To remove duplicate "Select Fee Structure"
        if (mArrFeeStructure.get(0).getFeeStructID() == mArrFeeStructure.get(1).getFeeStructID()) {
            mArrFeeStructure.remove(0);
        }
        ArrayAdapter<Fee> adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, mArrFeeStructure);
        mSpnFeeStruct.setAdapter(adapter);
        if (Current != 0) {
            mSpnFeeStruct.setSelection(getIndex(Current));
        }
    }

    private int getIndex(int fee) {
        for (int i = 0; i < mArrFeeStructure.size(); i++) {
            if (mArrFeeStructure.get(i).getFeeStructID() == fee) {
                return i;
            }
        }
        return 0;
    }

    private void setSyllabusSelectionMonth(String Current) {
        mArrSyllSelectionDate = new ArrayList<>();
        mArrSyllSelectionDate.add("Select Syllabus Selection Month*");
        mArrSyllSelectionDate.add("January");
        mArrSyllSelectionDate.add("February");
        mArrSyllSelectionDate.add("march");
        mArrSyllSelectionDate.add("april");
        mArrSyllSelectionDate.add("May");
        mArrSyllSelectionDate.add("June");
        mArrSyllSelectionDate.add("July");
        mArrSyllSelectionDate.add("August");
        mArrSyllSelectionDate.add("September");
        mArrSyllSelectionDate.add("October");
        mArrSyllSelectionDate.add("November");
        mArrSyllSelectionDate.add("December");
        adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, mArrSyllSelectionDate);
        mSpnSyllSelectionDate.setAdapter(adapter);
        if (Current != null) {
            mSpnSyllSelectionDate.setSelection(mArrSyllSelectionDate.indexOf(Current));
        }
    }

    private void setSessionStartMonth(String Current) {
        mArrSessionDate = new ArrayList<>();
        mArrSessionDate.add("Select Session Start Month*");
        mArrSessionDate.add("January");
        mArrSessionDate.add("February");
        mArrSessionDate.add("march");
        mArrSessionDate.add("april");
        mArrSessionDate.add("May");
        mArrSessionDate.add("June");
        mArrSessionDate.add("July");
        mArrSessionDate.add("August");
        mArrSessionDate.add("September");
        mArrSessionDate.add("October");
        mArrSessionDate.add("November");
        mArrSessionDate.add("December");
        adapter = new ArrayAdapter<>(getApplicationContext(), android.R.layout.simple_spinner_dropdown_item, mArrSessionDate);
        mSpnSessionDate.setAdapter(adapter);
        if (Current != null) {
            mSpnSessionDate.setSelection(mArrSessionDate.indexOf(Current));
        }
    }

    private void setShopReq(SchoolRegRequest obj) {
        obj.setID(mArrCustomers.get(SnpName.getSelectedItemPosition()).getID());
        obj.setShopOrSchoolName(edtShopname.getText().toString());
        obj.setPrincipleName(etdOwerName.getText().toString());
        obj.setPhone1(edtcellno.getText().toString());
        obj.setPhone2(edtcellnotwo.getText().toString());
        obj.setSalesOfficerID(mLoginResponse.getData().getSOID());
        obj.setEmail(edtemail.getText().toString());
        obj.setAddress(edtaddress.getText().toString());
        obj.setContactPerson(edtcontactperson.getText().toString());
        obj.setAreaID(mArrNewAreas.get(mSpnNewArea.getSelectedItemPosition()).getID());
        obj.setCityID(arrNewCities.get(mSpnNewCity.getSelectedItemPosition()).getID());
        obj.setContactPersonCellNo(edtcontactcellno.getText().toString());
        obj.setShopsRelatedToRetailer(mArrSelectedBookSellers);
        obj.setTehsilID(tehsilID);
        obj.setDistrictID(districtID);
        obj.setEducationSystem(mArrEduSys.get(mSpnEduSys.getSelectedItemPosition()));
        obj.setFeeStructure(mArrFeeStructure.get(mSpnFeeStruct.getSelectedItemPosition()).getFeeStructID());
        obj.setSessionStart(mArrSessionDate.get(mSpnSessionDate.getSelectedItemPosition()));
        obj.setSampleMonth(mArrSyllSelectionDate.get(mSpnSyllSelectionDate.getSelectedItemPosition()));
        obj.setCompititorInformation(mArrSyllabusItemsSelected);
        Log.e("Shops Size", "" + mArrSelectedBookSellers.size());
        if (edtNoOfBraches.getText().toString().isEmpty())
            obj.setNoOfBranches(0);
        else obj.setNoOfBranches(Integer.parseInt(edtNoOfBraches.getText().toString()));
        if (edtNoOfTeacher.getText().toString().isEmpty())
            obj.setNoOfTeachers(0);
        else obj.setNoOfTeachers(Integer.parseInt(edtNoOfTeacher.getText().toString()));
        if (edtstudentstr.getText().toString().length() > 0 || edtstudentstr.getText().toString() != null) {
            studentStrength = Integer.valueOf(edtstudentstr.getText().toString());
        }
        obj.setStudentStrength(studentStrength);
        obj.setToken(Token);
//        obj.setVerified();
    }

    private void callService_(int id) {
        mService = RestClient.getInstance(this);
        Call<GetServerResponse> userObject = mService.GetSchoolinfoForEdit(String.valueOf(id));
        RestCallbackObject callbackObject = new RestCallbackObject(this, this, RequestCode.API_GET_SCHOOL_INFO_FOR_EDIT_REQUEST_CODE).showProgress(true, 0).dontHideProgress(false);
        userObject.enqueue(callbackObject);
    }

    private void callRegService() {
        btnsbm.setEnabled(false);
        mDialog.show();
        mDialog.setMessage("Submitting Details please wait...");
        mService = RestClient.getInstance(this);
        Call<ServerResponse> userObject = mService.GetSchoolSchoolEditInfo(schoolRegRequest);
        RestCallbackObject callbackObject = new RestCallbackObject(this, this, RequestCode.EDIT_SCHOOL_REQUEST_INFO).showProgress(true, 0).dontHideProgress(false);
        userObject.enqueue(callbackObject);
    }

    @Override
    public void onSuccess(Object object, RequestCode requestCode) {
        if (requestCode == RequestCode.GET_CITIES_REQUEST_CODE) {
            if (mDialog.isShowing()) {
                mDialog.hide();
            }
            mCitiesResponse = (GetCitiesResponse) object;
            if (mCitiesResponse.getCities() != null) {
                arrCitiesRelatedToRegion = mCitiesResponse.getCities();
                arrNewCities = mCitiesResponse.getCities();
                setCitySpinner();
                setNewCitySpinner();
                mSpnCity.setVisibility(View.VISIBLE);
                mSpnNewCity.setVisibility(View.VISIBLE);
            } else {
                mSpnCity.setVisibility(View.GONE);
                mSpnNewCity.setVisibility(View.GONE);
                mSpnArea.setVisibility(View.GONE);
                SnpName.setVisibility(View.GONE);
                llMainLayout.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), "There are no cities associated", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == RequestCode.GET_AREA_REQUEST_CODE) {
            if (mDialog.isShowing()) {
                mDialog.hide();
            }
            mAreaResponse = (GetAreasResponse) object;
            if (mAreaResponse.getAreas() == null) {
                mSpnArea.setVisibility(View.GONE);
                SnpName.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), "There are no areas associated", Toast.LENGTH_SHORT).show();
            } else {
                mSpnArea.setVisibility(View.VISIBLE);
                setAreaSpinner(mAreaResponse);
            }
        } else if (requestCode == RequestCode.GET_AREAS_FOR_CITY) {
            if (mDialog.isShowing()) {
                mDialog.hide();
            }
            mNewAreaResponse = (GetAreasResponse) object;
            if (mNewAreaResponse.getAreas() == null) {
                mSpnNewArea.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), "There are no areas associated", Toast.LENGTH_SHORT).show();
            } else {
                mSpnNewArea.setVisibility(View.VISIBLE);
                setNewAreaSpinner(mNewAreaResponse);
            }
        } else if (requestCode == RequestCode.GET_CUSTOMER_RELATED_TO_SO) {
            GetServerResponse serverResponse = (GetServerResponse) object;
            if (mDialog.isShowing()) {
                mDialog.hide();
            }
            if (serverResponse.getCustomersRelatedtoSO() != null&&serverResponse.getCustomersRelatedtoSO().size()>0) {
                llMainLayout.setVisibility(View.VISIBLE);
                SnpName.setVisibility(View.VISIBLE);
                mArrCustomers = serverResponse.getCustomersRelatedtoSO();
                setCustomerSpinner();//hassan Usman Test 2
            } else {
                llMainLayout.setVisibility(View.GONE);
                SnpName.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), "There are no customers associated", Toast.LENGTH_LONG).show();
            }

        } else if (requestCode == RequestCode.API_GET_SCHOOL_INFO_FOR_EDIT_REQUEST_CODE) {
            GetServerResponse serverResponse = (GetServerResponse) object;
            if (serverResponse.getSchoolsForEdit() != null) {
                for (int i = 0; i < serverResponse.getSchoolsForEdit().size(); i++) {
                    formData = serverResponse.getSchoolsForEdit().get(i);
                    BookSellerIDs = serverResponse.getSylabusID();
                    PublisherIDs = serverResponse.getPublisherID();
                    getEditSchoolInfo(formData);
                }
                //assan Usman Test 2
            }
        } else if (requestCode == RequestCode.EDIT_SCHOOL_REQUEST_INFO) {
            ServerResponse serverResponse = (ServerResponse) object;
            if (serverResponse.getResultType() == ServerCodes.ServerResultType.SERVER_RESULT_SUCCESS) {
                Toast.makeText(this, serverResponse.getMessage(), Toast.LENGTH_LONG).show();
                onBackPressed();
            }
        } else if (requestCode == RequestCode.DELETE_SCHOOLS) {
            ServerResponse serverResponse = (ServerResponse) object;
            Toast.makeText(getApplicationContext(), serverResponse.getMessage(), Toast.LENGTH_LONG).show();
            onBackPressed();
        } else if (requestCode == RequestCode.GET_AREA_SELLERS) {
            mBookSellersResponse = (GetBookSellerResponse) object;
            if (mDialog.isShowing()) {
                mDialog.hide();
            }
            if (mBookSellersResponse.getBookSellers().size() <= 0) {
                Toast.makeText(getApplicationContext(), "There are No Sellers Associated", Toast.LENGTH_SHORT).show();
            } else {
                mArrBookSellers = mBookSellersResponse.getBookSellers();
                rlShowSellers.setVisibility(View.VISIBLE);
                mRvSellers.setVisibility(View.VISIBLE);
            }
        } else if (requestCode == RequestCode.GET_DISTRCIST) {
            if (mDialog.isShowing()) {
                mDialog.hide();
            }
            GetServerResponse response = (GetServerResponse) object;
            if (response.getDistricts().size() > 0) {
                mArrDistricts = response.getDistricts();
                setNewDistrictSpinner();
                Log.e("ALL CITIES", mArrDistricts.toString());
            } else {
                Toast.makeText(getApplicationContext(), "There are No Districts in this province", Toast.LENGTH_SHORT).show();
            }
        } else if (requestCode == RequestCode.GET_TEHSILS) {
            if (mDialog.isShowing()) {
                mDialog.hide();
            }
            GetServerResponse response = (GetServerResponse) object;
            if (response.getTehsils().size() > 0) {
                mArrTehsils = response.getTehsils();
                setNewTehsilSpinner();
                Log.e("ALL Tehsil", mArrTehsils.toString());
            } else {
                Toast.makeText(getApplicationContext(), "There are No Tehsils in this District", Toast.LENGTH_SHORT).show();
            }
        }
        mDialog.dismiss();
        mDialog.hide();
    }

    @Override
    public void onFailure(String error, RequestCode requestCode) {
        if (requestCode == RequestCode.GET_CUSTOMER_RELATED_TO_SO) {
            Toast.makeText(this, "Customer not Found", Toast.LENGTH_SHORT).show();

        } else if (requestCode == RequestCode.API_GET_SCHOOL_INFO_FOR_EDIT_REQUEST_CODE) {
            Toast.makeText(this, error, Toast.LENGTH_SHORT).show();

        } else if (requestCode == RequestCode.EDIT_SCHOOL_REQUEST_INFO) {
            btnsbm.setEnabled(true);
        } else if (requestCode == RequestCode.DELETE_SCHOOLS) {
            Toast.makeText(getApplicationContext(), error, Toast.LENGTH_LONG).show();
            onBackPressed();
        } else if (requestCode == RequestCode.GET_TEHSILS) {
            if (mDialog.isShowing()) {
                mDialog.dismiss();
            }
            Log.e("Result", "Failed");
        }
        mDialog.dismiss();
        mDialog.hide();
    }

    private final void focusOnView(final View view) {
        scrlEdit.post(new Runnable() {
            @Override
            public void run() {
                scrlEdit.scrollTo(0, view.getBottom());
            }
        });
    }

    private boolean validateForm() {
        if (newAreaPosition < 0) {
            showToast("Area");
            return false;
        } else if (mSpnNewDistrict.getSelectedItemPosition() == 0) {
            ((TextView) mSpnNewDistrict.getSelectedView()).setError("District is Empty");
            showToast("District");
            return false;
        } else if (mSpnNewTehsil.getSelectedItemPosition() == 0) {
            ((TextView) mSpnNewTehsil.getSelectedView()).setError("Tehsil is Empty");
            showToast("Tehsil");
            return false;
        } else {
            return true;
        }
    }

    private void showToast(String msg) {
        Toast.makeText(getApplicationContext(), msg + " is required", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void addRemoveItem(CurrentSyllabus item, boolean isAdd) {
        if (isAdd) {
            for (int i = 0; i < mArrSyllabusItems.size(); i++) {
                if (mArrSyllabusItems.get(i).equals(item)) {
                    mArrSyllabusItems.get(i).setISChecked(true);
                }
            }
            mArrSyllabusItemsSelected.add(item);
        } else {
            for (int i = 0; i < mArrSyllabusItems.size(); i++) {
                if (mArrSyllabusItems.get(i).equals(item)) {
                    mArrSyllabusItems.get(i).setISChecked(false);
                }
            }
            mArrSyllabusItemsSelected.remove(item);
        }
    }

    @Override
    public void addRemoveItem(GetBookSellerResponse.BookSeller item, boolean isAdd) {
        if (isAdd) {
            for (int i = 0; i < mArrBookSellers.size(); i++) {
                if (mArrBookSellers.get(i).equals(item)) {
                    mArrBookSellers.get(i).setChecked(true);
                }
            }
            mArrSelectedBookSellers.add(item);
        } else {
            for (int i = 0; i < mArrBookSellers.size(); i++) {
                if (mArrBookSellers.get(i).equals(item)) {
                    mArrBookSellers.get(i).setChecked(false);
                }
            }
            mArrSelectedBookSellers.remove(item);
        }

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_delete) {
            DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    switch (which) {
                        case DialogInterface.BUTTON_POSITIVE:
                            callgetDeeletSchool(mArrCustomers.get(customerPosition).getID());
                            break;
                        case DialogInterface.BUTTON_NEGATIVE:
                            dialog.dismiss();
                            break;
                    }
                }
            };
            if (SnpName.getSelectedItem() == null || mArrCustomers.size() <= 0) {
                Toast.makeText(getApplicationContext(), "There are no schools loaded yet...", Toast.LENGTH_LONG).show();
            } else {
                AlertDialog.Builder builder = new AlertDialog.Builder(EditSchoolInformation.this);
                builder.setMessage("Are you sure?").setPositiveButton("Yes", dialogClickListener)
                        .setNegativeButton("No", dialogClickListener).show();
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_delete, menu);
        return true;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSubmit:
                schoolRegRequest = new SchoolRegRequest();
                if (validateForm()) {
                    setShopReq(schoolRegRequest);
                    mDialog.setMessage("Submitting Details...");
                    mDialog.show();
                    callRegService();
                }
                break;
            case R.id.ib_show_seller_items:
                if (mArrBookSellers.size() > 0) {
                    if (mRvSellers.getVisibility() == View.GONE) {
                        mRvSellers.setVisibility(View.VISIBLE);
                        ibshowSellers.setBackgroundResource(R.drawable.ic_expand_less_black_24dp);
                        sellerLayoutManager = new LinearLayoutManager(getApplicationContext());
                        mRvSellers.setLayoutManager(sellerLayoutManager);
                        sellerAdapter = new BookSellerItemsAdapter(mArrBookSellers, this);
                        mRvSellers.setAdapter(sellerAdapter);
                    } else {
                        mRvSellers.setVisibility(View.GONE);
                        ibshowSellers.setBackgroundResource(R.drawable.ic_expand_more_black_24dp);
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "No item found", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.rl_select_Publishers:
                if (mArrSyllabusItems.size() > 0) {
                    if (mrvItems.getVisibility() == View.GONE) {
                        mrvItems.setVisibility(View.VISIBLE);
                        ibShowPublishers.setBackgroundResource(R.drawable.ic_expand_less_black_24dp);
                        mLayoutManager = new LinearLayoutManager(getApplicationContext());
                        mrvItems.setLayoutManager(mLayoutManager);
                        mAdapter = new SelectedPublisherItemsAdapter(mArrSyllabusItems, this, PublisherIDs);
                        mrvItems.setAdapter(mAdapter);
                    } else {
                        mrvItems.setVisibility(View.GONE);
                        ibShowPublishers.setBackgroundResource(R.drawable.ic_expand_more_black_24dp);
                    }
                } else
                    Toast.makeText(getApplicationContext(), "No item found", Toast.LENGTH_SHORT).show();
                break;
            case R.id.rl_select_Sellers:
                if (mArrBookSellers.size() > 0) {
                    if (mRvSellers.getVisibility() == View.GONE) {
                        mRvSellers.setVisibility(View.VISIBLE);
                        ibshowSellers.setBackgroundResource(R.drawable.ic_expand_less_black_24dp);
                        sellerLayoutManager = new LinearLayoutManager(getApplicationContext());
                        mRvSellers.setLayoutManager(sellerLayoutManager);
                        sellerAdapter = new SelectedBookSellerItemsAdapter(mArrBookSellers, this, BookSellerIDs);
                        mRvSellers.setAdapter(sellerAdapter);
                    } else {
                        mRvSellers.setVisibility(View.GONE);
                        ibshowSellers.setBackgroundResource(R.drawable.ic_expand_more_black_24dp);
                    }
                } else {
                    Toast.makeText(getApplicationContext(), "No item found", Toast.LENGTH_SHORT).show();
                }
                break;

        }


    }
}
