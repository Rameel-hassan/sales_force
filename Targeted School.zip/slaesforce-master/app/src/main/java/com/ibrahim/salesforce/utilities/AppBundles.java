package com.ibrahim.salesforce.utilities;

public interface AppBundles {
    String BUNDLE_SHOP_NAME = "bundle_shop_name";
    String BUNDLE_CUSTOMER_OBJ = "bundle_customer_obj";
    String BUNDLE_ORDER = "bundle_order";
    String BUNDLE_VISIT_TYPE = "visit_type";
    String DEALERS_LIST = "dealer_list";
}
