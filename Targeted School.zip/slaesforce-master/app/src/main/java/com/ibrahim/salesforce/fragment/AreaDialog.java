package com.ibrahim.salesforce.fragment;

public interface AreaDialog{
    void areaAdded();
}