package com.ibrahim.salesforce.activity;

import static com.ibrahim.salesforce.utilities.AppPreference.FIRST_TIME_APP_RUN;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.content.res.Configuration;
import android.graphics.Color;

import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationView;
import com.ibrahim.salesforce.R;
import com.ibrahim.salesforce.adapters.TodayRemindersAdapter;
import com.ibrahim.salesforce.dialoge.DetailsDialogFragment;
import com.ibrahim.salesforce.dialoge.NearBySchoolsFragment;
import com.ibrahim.salesforce.dialoge.ResetLatLongDialog;
import com.ibrahim.salesforce.model.MainOption;
import com.ibrahim.salesforce.network.ApiService;
import com.ibrahim.salesforce.network.RequestCode;
import com.ibrahim.salesforce.network.RestCallbackObject;
import com.ibrahim.salesforce.network.RestClient;
import com.ibrahim.salesforce.network.ServerConnectListenerObject;
import com.ibrahim.salesforce.permissions.RuntimePermissionHandler;
import com.ibrahim.salesforce.permissions.RuntimePermissionUtils;
import com.ibrahim.salesforce.response.GetServerResponse;
import com.ibrahim.salesforce.response.MainDashboardEntry;
import com.ibrahim.salesforce.response.TodayActiveReminders;
import com.ibrahim.salesforce.services.DBLocationPointsSyncService;
import com.ibrahim.salesforce.services.LocationUpdateService;
import com.ibrahim.salesforce.utilities.AppBundles;
import com.ibrahim.salesforce.utilities.AppKeys;
import com.ibrahim.salesforce.utilities.AppPreference;
import com.ibrahim.salesforce.utilities.GPSTrackerService;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import io.paperdb.Paper;
import retrofit2.Call;

public class DashboardActivity extends AppCompatActivity implements
        NavigationView.OnNavigationItemSelectedListener , SwipeRefreshLayout.OnRefreshListener, ServerConnectListenerObject {
    private RecyclerView rcOptions;
    private TextView appVersion;
    private Context mContext;
    private Dialog detailsDialog;
    private String versionName;
    private ApiService mService;

    private GetServerResponse mLoginResponse;
    SwipeRefreshLayout swipeRefreshLayout;

    private RecyclerView rv_reminders;

    private List<MainOption> lstallOptions;
    private final int REQ_CODE_LOCATION_PERMISSION = 1002;
    private final int REQ_CODE_STORAGE_PERMISSION = 1003;
    NavigationView navigationView;
    ActionBarDrawerToggle toggle;
    DrawerLayout Drawer;
    ActionBar actionBar;
    BottomNavigationView bottomNavigationView;
    LinearLayout totalSampleVisit;
    LinearLayout totalSampeledelevered;
    LinearLayout totalsamplereturn;
    LinearLayout totalSelectedbooks;
    LinearLayout ll_today_reminders;
    TextView mTotalVisit;
    TextView mTotaldelevered;
    TextView mTotalreturn;
    TextView mTotalbooks;
    TextView mTotalTarget;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



        setContentView(R.layout.activitydashboard);
        mContext = this;
        ll_today_reminders=findViewById(R.id.ll_today_reminders);
        navigationView = findViewById(R.id.nav_view);
        bottomNavigationView = findViewById(R.id.botton_navigation_id);
        totalSampleVisit = findViewById(R.id.total_sample_visits);
        totalSampeledelevered = findViewById(R.id.total_sample_delivered);
        totalsamplereturn = findViewById(R.id.total_sample_return);
        totalSelectedbooks = findViewById(R.id.total_selected_books);

        rv_reminders=findViewById(R.id.rv_reminders);

        mTotalVisit = findViewById(R.id.textview_total_visit);
        mTotaldelevered = findViewById(R.id.textview_total_delivery);
        mTotalreturn = findViewById(R.id.textview_total_return);
        mTotalbooks = findViewById(R.id.textview_total_selected_books);
        mTotalTarget = findViewById(R.id.textview_total_target_value);

        swipeRefreshLayout=(SwipeRefreshLayout)findViewById(R.id.swipeRefreshLayout);
        navigationView.setItemIconTintList(null);
        navigationView.setItemTextColor(ColorStateList.valueOf(Color.WHITE));


        Toolbar toolbar = findViewById(R.id.toolbar);
        toolbar.setTitle("");
        setSupportActionBar(toolbar);
        Drawer = findViewById(R.id.drawerlayout);
        navigationView.setNavigationItemSelectedListener((NavigationView.OnNavigationItemSelectedListener) this);
        navigationView.bringToFront();
        toggle = new ActionBarDrawerToggle(this, Drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        toggle.setDrawerIndicatorEnabled(true);

        Drawer.addDrawerListener(toggle);

        toggle.syncState();
        actionBar = getSupportActionBar();
        actionBar.setHomeButtonEnabled(true);
        actionBar.setDisplayHomeAsUpEnabled(true);




        totalSampleVisit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startIntent(3);

            }
        });
        totalSampeledelevered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        totalsamplereturn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });
        totalSelectedbooks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.school_registration_:
                        startIntent(1);
                        break;

                    case R.id.online_visits_:
                        showEditDialog(7);
                        break;

                    case R.id.mark_attendance_:
                        startIntent(6);

                        break;


                }

                return false;
            }
        });

//        appVersion.setText("V: " + versionName);

        boolean isAutoStartEnabled = AppPreference.getSavedData(getApplicationContext(),FIRST_TIME_APP_RUN);
        if (!isAutoStartEnabled) {
//            enableAutoStart();
            showAutoStartScreen();
            AppPreference.saveData(getApplicationContext(),true,FIRST_TIME_APP_RUN);

        }

//        initGui(SFApplication.getAppResources().getString(R.string.dashboard));
        Log.d("class_name", this.getClass().getSimpleName());
        Paper.init(this);
        runServiceIfAlreadyPresent();

        initTodayReminders();

        hideItem();
        swipeRefreshLayout.setOnRefreshListener(this);
        swipeRefreshLayout.setColorSchemeResources(R.color.colorAccent,R.color.colorPrimary);
    }



    private void showAutoStartScreen() {
         final Intent[] POWERMANAGER_INTENTS = {
                new Intent().setComponent(new ComponentName("com.miui.securitycenter", "com.miui.permcenter.autostart.AutoStartManagementActivity")),
                new Intent().setComponent(new ComponentName("com.letv.android.letvsafe", "com.letv.android.letvsafe.AutobootManageActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.startupmgr.ui.StartupNormalAppListActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.optimize.process.ProtectActivity")),
                new Intent().setComponent(new ComponentName("com.huawei.systemmanager", "com.huawei.systemmanager.appcontrol.activity.StartupAppControlActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.permission.startup.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.coloros.safecenter", "com.coloros.safecenter.startupapp.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.oppo.safe", "com.oppo.safe.permission.startup.StartupAppListActivity")),
                new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.AddWhiteListActivity")),
                new Intent().setComponent(new ComponentName("com.iqoo.secure", "com.iqoo.secure.ui.phoneoptimize.BgStartUpManager")),
                new Intent().setComponent(new ComponentName("com.vivo.permissionmanager", "com.vivo.permissionmanager.activity.BgStartUpManagerActivity")),
                new Intent().setComponent(new ComponentName("com.samsung.android.lool", "com.samsung.android.sm.ui.battery.BatteryActivity")),
                new Intent().setComponent(new ComponentName("com.htc.pitroad", "com.htc.pitroad.landingpage.activity.LandingPageActivity")),
                new Intent().setComponent(new ComponentName("com.asus.mobilemanager", "com.asus.mobilemanager.MainActivity"))
        };

        for (Intent intent : POWERMANAGER_INTENTS)
            if (getPackageManager().resolveActivity(intent, PackageManager.MATCH_DEFAULT_ONLY) != null) {
                // show dialog to ask user action
                new AlertDialog.Builder(DashboardActivity.this).setTitle("Enable AutoStart")
                        .setMessage(
                                "Please allow sales automation to always run in the background,else our services can't be accessed.")
                        .setPositiveButton("ALLOW", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                startActivity(intent);
                            }
                        })
                        .show();

                break;
            }

    }
    private ProgressDialog mDialog;
    private void loadTodayReminders() {
        mDialog = new ProgressDialog(this);
        mDialog.setCancelable(false);
       // Toast.makeText(this,getTodayDate(),Toast.LENGTH_SHORT).show();
        mDialog.setMessage("Getting Today Reminders, please wait...");
        mDialog.show();
        mService = RestClient.getInstance(this);
        Call<GetServerResponse> userObject = mService.getTodayReminders(mLoginResponse.getData().getSOID(),getTodayDate());
        RestCallbackObject callbackObject = new RestCallbackObject((Activity)
                mContext, this, RequestCode.GET_TODAY_REMINDERS)
                .showProgress(true, 0)
                .dontHideProgress(false);
        userObject.enqueue(callbackObject);
    }

    private String getTodayDate() {
       return new SimpleDateFormat("MM-dd-yyyy", Locale.getDefault()).format(new Date());
    }

    private void hideItem()
    {
        if (!mLoginResponse.getData().getIsRegionalHead()) {
            Menu nav_Menu = navigationView.getMenu();
            nav_Menu.findItem(R.id.routeHostory).setVisible(false);
        }
        if (mLoginResponse.getData().getIsAssignSampleMenu()) {
            Menu nav_Menu = navigationView.getMenu();
            nav_Menu.findItem(R.id.manage_books_samples_info).setVisible(true);
        }
        if (mLoginResponse.getData().getIsRm()) {
            Menu nav_Menu = navigationView.getMenu();
            nav_Menu.findItem(R.id.get_visit).setVisible(true);
        }

    }
    private void runServiceIfAlreadyPresent() {
        mLoginResponse = Paper.book().read(AppKeys.KEY_LOGIN_RESPONSE);
        getDashBoardEntries(mLoginResponse.getData().getSOID());

        if (mLoginResponse.getData().getIsMarked() && !mLoginResponse.getData().getIsCheckOut()){
            if (!isMyServiceRunning(LocationUpdateService.class)) {
                Log.d("FragmentMainActivity", "onCreate: isMyServiceRunning = true");
                startService(new Intent(getApplicationContext(), LocationUpdateService.class));

            }
        }else {
            stopLocationServiceIfRunning();
        }

    }
    public void stopLocationServiceIfRunning(){
        if (isMyServiceRunning(LocationUpdateService.class)) {
            Log.d("FragmentMainActivity", "onCreate: isMyServiceRunning = true");
            stopService(new Intent(DashboardActivity.this, LocationUpdateService.class));

        }else{
            Log.d("FragmentMainActivity", "onCreate: isMyServiceRunning = false");
        }
    }
    protected boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager)DashboardActivity.this.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }
    private RuntimePermissionHandler.PermissionListener mPermissionListener = new RuntimePermissionHandler.PermissionListener() {
        @Override
        public void onRationale(final @NonNull RuntimePermissionHandler.PermissionRequest permissionRequest, final Activity target, final int requestCode, @NonNull final String[] permissions) {
            switch (requestCode) {
                case REQ_CODE_LOCATION_PERMISSION:
                    new AlertDialog.Builder(target)
                            .setPositiveButton(R.string.allow, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(@NonNull DialogInterface dialog, int which) {
                                    permissionRequest.proceed(target, requestCode, permissions);
                                    dialog.dismiss();
                                }
                            })
                            .setNegativeButton(R.string.deny, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(@NonNull DialogInterface dialog, int which) {
                                    permissionRequest.cancel(target, requestCode, permissions);
                                    dialog.dismiss();
                                }
                            })
                            .setCancelable(false)
                            .setMessage(R.string.location_permission_rational)
                            .show();
                    break;
                case REQ_CODE_STORAGE_PERMISSION:
                    new AlertDialog.Builder(target)
                            .setPositiveButton(R.string.allow, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(@NonNull DialogInterface dialog, int which) {
                                    permissionRequest.proceed(target, requestCode, permissions);
                                    dialog.dismiss();
                                }
                            })
                            .setNegativeButton(R.string.deny, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(@NonNull DialogInterface dialog, int which) {
                                    permissionRequest.cancel(target, requestCode, permissions);
                                    dialog.dismiss();
                                }
                            })
                            .setCancelable(false)
                            .setMessage("Storage permission is needed to save images")
                            .show();
                    break;

            }
        }

        @Override
        public void onAllowed(int requestCode, @NonNull String[] permissions) {
            switch (requestCode) {
                case REQ_CODE_LOCATION_PERMISSION:
                    mLocationService.getLocation();
                    //getLocation();
                    break;
            }
        }

        @Override
        public void onDenied(final @NonNull RuntimePermissionHandler.PermissionRequest permissionRequest, Activity target, int requestCode, @NonNull String[] permissions,
                             @NonNull int[] grantResults, RuntimePermissionHandler.DENIED_REASON deniedReason) {
            if (deniedReason == RuntimePermissionHandler.DENIED_REASON.USER) {
                switch (requestCode) {
                    case REQ_CODE_LOCATION_PERMISSION:
                        Toast.makeText(target, R.string.location_permission_denied, Toast.LENGTH_SHORT).show();
                        break;
                    case REQ_CODE_STORAGE_PERMISSION:
                        Toast.makeText(target, "Storage permission denied by user", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        }

        @Override
        public void onNeverAsk(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
            switch (requestCode) {
                case REQ_CODE_LOCATION_PERMISSION:
                    new AlertDialog.Builder(DashboardActivity.this)
                            .setPositiveButton(R.string.allow, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(@NonNull DialogInterface dialog, int which) {
                                    RuntimePermissionUtils.openAppSettings(DashboardActivity.this);
                                }
                            })
                            .setNegativeButton(R.string.deny, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(@NonNull DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            })
                            .setCancelable(false)
                            .setMessage(R.string.location_permission_denied)
                            .show();
                    break;
                case REQ_CODE_STORAGE_PERMISSION:
                    new AlertDialog.Builder(DashboardActivity.this)
                            .setPositiveButton(R.string.allow, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(@NonNull DialogInterface dialog, int which) {
                                    RuntimePermissionUtils.openAppSettings(DashboardActivity.this);
                                }
                            })
                            .setNegativeButton(R.string.deny, new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(@NonNull DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            })
                            .setCancelable(false)
                            .setMessage("Storage permission denied by user")
                            .show();
                    break;
            }
        }
    };


    private void showEditDialogFrg(int type) {
        FragmentManager fm = getSupportFragmentManager();
        NearBySchoolsFragment editNearBySchoolsActivity = NearBySchoolsFragment.newInstance("Information", this, type);
        editNearBySchoolsActivity.show(fm, "fragment_edit_name");
    }

    private void showEditDialog(int type) {
        FragmentManager fm = getSupportFragmentManager();
        DetailsDialogFragment editNameDialogFragment = DetailsDialogFragment.newInstance("Information", this, type);
        editNameDialogFragment.show(fm, "fragment_edit_name");
    }

    private void showResetLatLongDialog() {
        FragmentManager fm = getSupportFragmentManager();
        ResetLatLongDialog rsll = ResetLatLongDialog.newInstance("Information", this);
        rsll.show(fm, "fragment_edit_name");
    }

    public void getcurrentLocationStart() {
        RuntimePermissionHandler.requestPermission(REQ_CODE_LOCATION_PERMISSION, this, mPermissionListener, RuntimePermissionUtils.LocationPermission);
    }

    public boolean isStoragePermissionGranted() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    == PackageManager.PERMISSION_GRANTED) {
                return true;
            } else {

                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
                return false;
            }
        } else {
            return true;
        }
    }

    public void getStoragePermission() {
        RuntimePermissionHandler.requestPermission(REQ_CODE_STORAGE_PERMISSION, this, mPermissionListener, RuntimePermissionUtils.StoragePermission);

    }

    @Override
    public void onStart() {
        super.onStart();
        //TO CHECK STORAGE PERMISSION
        Intent intent = new Intent(this, GPSTrackerService.class);
        bindService(intent, mConnection, Context.BIND_AUTO_CREATE);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            getcurrentLocationStart();

       // loadTodayReminders();
        //else
        //  mLocationService.getLocation();
    }


    public void initTodayReminders(){

        if (mLoginResponse.getData().getTodayReminders()!=null&&!mLoginResponse.getData().getTodayReminders().isEmpty()) {
            ll_today_reminders.setVisibility(View.VISIBLE);
            ArrayList<TodayActiveReminders> reminders= mLoginResponse.getData().getTodayReminders();

            TodayRemindersAdapter adapter=new TodayRemindersAdapter(reminders);

            rv_reminders.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.VERTICAL,false));

            rv_reminders.setAdapter(adapter);

        } else {
            ll_today_reminders.setVisibility(View.GONE);
            Toast.makeText(getApplicationContext(), "There are no reminders for today.", Toast.LENGTH_LONG).show();
        }
    }


    @Override
    public void onStop() {
        super.onStop();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Intent intent = new Intent(this, GPSTrackerService.class);
        unbindService(mConnection);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mLocationService != null && mLocationService.isShowingSettingDialog) {
            mLocationService.isShowingSettingDialog = false;
            mLocationService.getLocation();
        }
        //todo confirm if head also make attendence
//        if (!mLoginResponse.getData().getIsRegionalHead()) {
            Intent serviceIntent = new Intent(DashboardActivity.this, DBLocationPointsSyncService.class);
            ContextCompat.startForegroundService(DashboardActivity.this, serviceIntent);
//        }
    }

    public static GPSTrackerService mLocationService = new GPSTrackerService();

    boolean mBound = false;
    /**
     * Defines callbacks for service binding, passed to bindService()
     */
    private ServiceConnection mConnection = new ServiceConnection() {

        @Override
        public void onServiceConnected(ComponentName className,
                                       IBinder service) {
            // We've bound to LocalService, cast the IBinder and get LocalService instance
            GPSTrackerService.LocalBinder binder = (GPSTrackerService.LocalBinder) service;
            mLocationService = binder.getService(mContext);
            //if (mLocationService.isGSPOn()) {
            mLocationService.getLocation();
            //}
            mBound = true;

        }

        @Override
        public void onServiceDisconnected(ComponentName arg0) {
            mBound = false;
        }
    };


    private void startIntent(Context context, Class cls) {
        Intent intent = new Intent(context, cls);
        startActivity(intent);
    }

    private void startIntent(int type) {
        Intent intent = new Intent(mContext, FragmentShownActivity.class);
        intent.putExtra(AppKeys.FRAGMENT_TYPE, type);
        startActivity(intent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_favorite) {
            startIntent(7);
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
        switch (menuItem.getItemId()) {
            case R.id.dashbaord:
                startIntent(getApplicationContext(), NewDashBoardActivity.class);
                break;
            case R.id.online_attendance:
                startIntent(6);
                break;
            case R.id.school_registration:
                startIntent(1);
                break;
            case R.id.update_school:
                startIntent(getApplicationContext(), EditSchoolInformation.class);
                break;
            case R.id.online_schools:
                showEditDialog(7);
                break;
            case R.id.offline_school:
                showEditDialog(8);
                break;
            case R.id.add_targeted_school:
               // showEditDialog(18);
                Intent intent = new Intent(mContext, AddTargetedSchool.class);
                startActivity(intent);
                break;
            case R.id.mi_not_interested_visit:
                startIntent(getApplicationContext(), NotInterestedVisit.class);
                break;
            case R.id.my_visits:
                startIntent(3);
                break;
            case R.id.visit_map_view:
                startIntent(getApplicationContext(), MapsActivity.class);
                break;
            case R.id.mi_visit_history:
                startIntent(getApplicationContext(), VisitHistoryActivity.class);
                break;
            case R.id.routeHostory:
                startIntent(getApplicationContext(), MapsRoutesActivity.class);
                break;
            case R.id.manage_books_samples_info:
                startIntent(getApplicationContext(), BooksCollectionActivity.class);
                break;
            case R.id.session_wise_school:
                startIntent(8);
                break;
            case R.id.multi_purpose_visit:
                startIntent(getApplicationContext(), MultiPurposeActivityMenu.class);
                break;
            case R.id.reset_location:
                showResetLatLongDialog();
                break;
            case R.id.expense_sheets:
                startIntent(getApplicationContext(), DailyExpenseReport.class);
                break;

            case R.id.near_by_school:
                showEditDialogFrg(15);
                startIntent(getApplicationContext(), NearBySchoolsActivity.class);
                break;
            case R.id.mi_sale_history:
                startIntent(getApplicationContext(),SampleHistoryActivity.class);
                break;
            case R.id.reminders:
                startIntent(5);
                break;

            case R.id.current_location:
                startIntent(4);
                break;

            case R.id.set_visit:
                startIntent(9);
                break;
            case R.id.get_visit:
                startIntent(10);
                break;
            case R.id.shop_registration:
                startIntent(2);
                break;

//        rcOptions.addOnItemTouchListener(
//                new RecyclerItemClickListener(this, rcOptions, new RecyclerItemClickListener.OnItemClickListener() {
//                    @Override
//                    public void onItemClick(View view, int position) {
//                        MainOption option = lstallOptions.get(position);
//                        if (option.getOption_name() == "Dashboard") {
//                            startIntent(getApplicationContext(), NewDashBoardActivity.class);
//                        } else if (option.getOption_name() == "School Registration") {
//                            startIntent(1);
//                        } else if (option.getOption_name() == "Shop Registration") {
//                            startIntent(2);
//                        } else if (option.getOption_name() == "My Visits") {
//                            startIntent(3);
//                        } else if (option.getOption_name() == "My Current Location") {
//                            startIntent(4);
//                        } else if (option.getOption_name() == "Reminders") {
//                            startIntent(5);
//                        } else if (option.getOption_name() == "Online Attendance") {
//                            startIntent(6);
//                        } else if (option.getOption_name() == "Visit Details") {
//                            showEditDialog(7);
//                        } else if (option.getOption_name() == "Session Wise Schools") {
//                            startIntent(8);
//                        } else if (option.getOption_name() == "Set Visit Plan") {
//                            startIntent(9);
//                        } else if (option.getOption_name() == "Visit Plan Details") {
//                            startIntent(10);
//                        } else if (option.getOption_name() == "Reset Location") {
//                            showResetLatLongDialog();
//                        } else if (option.getOption_name() == "Activity MapView") {
//                            startIntent(getApplicationContext(), MapsActivity.class);
//                        }else if (option.getOption_name() == "Edit School Info") {
//                            startIntent(getApplicationContext(), EditSchoolInformation.class);
//                        } else if (option.getOption_name() == "Offline Visits") {
//                            showEditDialog(8);
//                        } else if (option.getOption_name() == "Delete School") {
//                            showEditDialog(10);
//                        } else if (option.getOption_name() == "Daily Expense Report") {
//                            startIntent(getApplicationContext(), DailyExpenseReport.class);
//                        } else if (option.getOption_name() == "MultiPurpose Visit") {
//                            startIntent(getApplicationContext(), MultiPurposeActivityMenu.class);
//                        } else if (option.getOption_name() == "Download Data") {
//                            startIntent(getApplicationContext(), SyncDataActivity.class);
//                        } else if(option.getOption_name() == "Near By Schools") {
//                            showEditDialogFrg(15);
////                            startIntent(getApplicationContext(), NearBySchoolsActivity.class);
//                        }
//                    }
//
//                    @Override
//                    public void onLongItemClick(View view, int position) {
//                        // do whatever
//                    }
//                })
//        );
//    }

        }

        Drawer.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        toggle.syncState();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        toggle.onConfigurationChanged(newConfig);
    }

    @Override
    public void onRefresh() {
        if (swipeRefreshLayout.isRefreshing()) {
            swipeRefreshLayout.setRefreshing(false);
        }

        getDashBoardEntries(mLoginResponse.getData().getSOID());
        Log.d("DashboardActivity", "onRefresh: called");
//            syncMasters();
    }

    @Override
    public void onFailure(String error, RequestCode requestCode) {
        if (requestCode == RequestCode.API_GET_DASHBOARD_ENTRIES) {
            if (swipeRefreshLayout.isRefreshing()) {
                swipeRefreshLayout.setRefreshing(false);
            }
            Toast.makeText(getApplicationContext(),error,Toast.LENGTH_SHORT).show();
        }else if(requestCode==RequestCode.GET_TODAY_REMINDERS){
            if(mDialog!=null&&mDialog.isShowing()){
                mDialog.dismiss();
            }
            ll_today_reminders.setVisibility(View.GONE);
            Toast.makeText(getApplicationContext(),error,Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(getApplicationContext(),error,Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onSuccess(Object object, RequestCode requestCode) {
        if (requestCode == RequestCode.API_GET_DASHBOARD_ENTRIES) {
            if (swipeRefreshLayout.isRefreshing()) {
                swipeRefreshLayout.setRefreshing(false);
            }
             MainDashboardEntry dashboardEntry= ((GetServerResponse) object).getMainDashboard();
            setValueInDashBoard(dashboardEntry);
            Log.d("DashboardActivity", "onSuccess: dashboard entries");
        }else if(requestCode==RequestCode.GET_TODAY_REMINDERS){

            if (mDialog.isShowing()) {
                mDialog.hide();
            }
        }
    }

    private void setValueInDashBoard(MainDashboardEntry dashboardEntry) {
         mTotalVisit.setText("Visits : "+dashboardEntry.getTotalVisits());
         mTotaldelevered.setText("Sample deliver : "+dashboardEntry.getTotalSampleDeliver());
         mTotalreturn.setText("Sample Return : "+dashboardEntry.getTotalSampleReturn());
         mTotalbooks.setText("Selected Books : "+dashboardEntry.getTotalSelectedBooks());
        mTotalTarget.setText("Target Value : "+dashboardEntry.getTargetValue());
    }

    private void getDashBoardEntries(int soid) {
        mService = RestClient.getInstance(this);
        Call<GetServerResponse> userObject = mService.getDashBoardData(soid);
        RestCallbackObject callbackObject = new RestCallbackObject(this, this, RequestCode.API_GET_DASHBOARD_ENTRIES);
        userObject.enqueue(callbackObject);
    }

}
